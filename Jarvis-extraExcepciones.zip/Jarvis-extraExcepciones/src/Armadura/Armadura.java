/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Armadura;

import static java.lang.Float.parseFloat;
import static java.lang.Integer.parseInt;
import java.util.Scanner;

/**
 *
 * @author max72
 */
public class Armadura {

    private String colorPrimario;
    private String colorSecundario;
    private float nivelResistencia;
    private float nivelSalud;
    private Bota botas;
    private Guante guantes;
    private Casco casco;
    private Generador generador;

    public Armadura() {
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        try {
            System.out.println("Ingrese color primario!");
            colorPrimario = leer.next();
            System.out.println("Ahora Secundario");
            colorSecundario = leer.next();
            if (colorSecundario.isEmpty() || colorPrimario.isEmpty()) {
                throw new Exception("Color incorrecto, aprenda a escribir");
            }
        } catch (Exception e) {
            //System.out.println("Colores incorrectos. No se como hiciste, pero te copaste.");
            System.out.println(e);
            System.out.println("Colores fueron elegidos por default: ROJO Y DORADO");
            colorPrimario = "Rojo";
            colorSecundario = "Dorado";
        }
        try {
            System.out.println("Ingrese nivel salud");
            nivelSalud = parseInt(leer.next());
        } catch (NumberFormatException e) {
            System.out.println("Numero incorrecto. Se eligio default (100)");
            nivelSalud = 100;
        }
        try {
            System.out.println("Ingrese nivel de resistencia (Float)");
            nivelResistencia = parseFloat(leer.next());
        } catch (NumberFormatException e) {
            System.out.println("Numero incorrecto. Se eligio default (100)");
            nivelResistencia = 100;
        }
        casco = new Casco();
        generador = new Generador(1000);
        System.out.println("Generador cargado al 100% ");
        System.out.println("Bienvenido, Tony. Soy Jarvis, su asistente AI personal para hosts imbeciles");
        botas = new Bota();
        guantes = new Guante();
    }

    private boolean gastarEnergia(float energiaGastada) {
        if (!generador.gastarEnergia(energiaGastada)) {
            System.out.println("Accion imposible Tony, no tienes suficiente energia en el generador! D:");
            return false;
        }
        return true;
    }

    private float caminar(int segundos) {
        return botas.consumoBasico * botas.estadoRotil() * segundos;
    }

    private float correr(int segundos) {
        return botas.consumoNormal * botas.estadoRotil() * segundos;

    }

    private float propulsarse(int segundos) {
        return botas.consumoIntensivo * botas.estadoRotil() * segundos;

    }

    private float volar(int segundos) {
        return ((botas.consumoIntensivo * botas.estadoRotil() + guantes.consumoNormal * guantes.estadoRotil()) * segundos);
    }

    private boolean ejecutarAccion(int segundos, int accion, int intentosExtra) {
        float consumo = intentosExtra + casco.consumoBasico * 2; //Porque se supone que se usan dos comandos de hablar para decir que accion y cuantos seg, asi que se usan dos.
        //acciones: 1. Caminar, 2. Correr, 3. Propulsarse, 4. volar.

        if (accion == 1) {
            consumo += caminar(segundos);
        }
        if (accion == 2) {
            consumo += correr(segundos);
        }
        if (accion == 3) {
            consumo += propulsarse(segundos);
        }
        if (accion == 4) {
            consumo += volar(segundos);
        }
        return gastarEnergia(consumo);
    }

    private void jarvisPlease(int intentosExtra) {

        int i = 0 + intentosExtra;
        int accion = 0;
        int segundos = 0;
        while (accion == 0) {
            accion = validarAccion();
            i++;
        }
        while (segundos == 0) {
            segundos = validarTiempo();
            i++;
        }
        //System.out.println("Llevaste intentos: " + i);
        if (ejecutarAccion(segundos, accion, i)) {
            System.out.println("Hecho Tony. Energia al " + generador.getNivelDeEnergia());
        } else {
            System.out.println("He fallado. Energia al " + generador.getNivelDeEnergia());
        }

    }

    private int validarTiempo() {
        int segs;
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        try {
            System.out.println("Tony, cuanto tiempo? En segs");
            segs = parseInt(leer.next());
        } catch (NumberFormatException e) {
            System.out.println("Tony, es ud imbecil, eso no es un numero");
            return 0;
        }
        return segs;
    }

    private int validarAccion() {
        int accion;
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        try {
            System.out.println("Tony, que sucede amiguito, que quiere ud hacer");
            System.out.println("1. Caminar, 2. Correr, 3. Propulsarse, 4. Volar ");
            System.out.println("Ingrese una accion");
            accion = parseInt(leer.next());
        } catch (NumberFormatException e) {
            System.out.println("Tony, es ud imbecil, eso no es una accion, ni siquiera es un numero");
            return 0;
        }
        if (accion < 1 || accion > 4) {
            System.out.println("Tony, no sea imbecil, esa opcion no existe");
            return 0;
        }
        return accion;
    }

    public void menu() {
        int opcion = 0;
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        int i = 0;
        while (opcion != 2) {
            i++;
            System.out.println("Hola, jefecito. Que puedo hacer por ud?");
            System.out.println("1. Ejecutar alguna accion");
            System.out.println("2. Salir del traje");
            try {
                opcion = parseInt(leer.next());
                if (opcion == 1) {
                    jarvisPlease(i);
                } else if (opcion != 2) {
                    System.out.println("Opcion incorrecta, Tony");
                } else {
                    System.out.println("Adios jefecito");
                }
            } catch (NumberFormatException e) {
                System.out.println("Tony, mi viejo amigo, eso no es una opcion");
            }
        }
    }

    public void cargarGenerador() {
        System.out.println("Cargando bateria hasta los cuetes");
        generador.llenarGenerador();
        System.out.println("El generador ahora esta en " + generador.getNivelDeEnergia());
    }

    public void mostrarInfoReactor() {
        System.out.println("El reactor tiene " + generador.getNivelDeEnergia() + "kW de Energia");
        System.out.println("Que es lo mismo que " + generador.getNivelDeEnergia()*10 + "mW de Energia");
        System.out.println("Que es lo mismo que " + generador.getNivelDeEnergia()*0.8 + "KVA de Energia");
    }
    
    

}
