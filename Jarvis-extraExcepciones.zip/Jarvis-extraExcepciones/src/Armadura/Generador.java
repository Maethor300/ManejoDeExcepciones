/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Armadura;

/**
 *
 * @author max72
 */
public class Generador {

    private float nivelDeEnergia;

    public float getNivelDeEnergia() {
        return nivelDeEnergia;
    }

    public Generador(float nivelDeEnergia) {
        this.nivelDeEnergia = nivelDeEnergia;
    }

    public boolean gastarEnergia(float energiaGastada) {
        if (nivelDeEnergia >= energiaGastada) {
            nivelDeEnergia -= energiaGastada;
            return true;
        }
        return false;
    }

    public void llenarGenerador() {
        nivelDeEnergia = Float.MAX_VALUE;
    }

}
