/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Armadura;

/**
 *
 * @author max72
 */
public class Bota {

    Dispositivos bota1;
    Dispositivos bota2;
    float consumoBasico;
    float consumoNormal;
    float consumoIntensivo;

    public Bota() {
        bota1 = new Dispositivos();
        bota2 = new Dispositivos();
        consumoBasico = bota1.consumoBasico;
        consumoNormal = bota1.consumoNormal;
        consumoIntensivo = bota1.consumoIntensivo;
    }

    public int estadoRotil() {
        if (bota1.estoyRoto && bota2.estoyRoto) {
            return 0;
        } else if (bota1.estoyRoto || bota2.estoyRoto) {
            return 1;
        } else {
            return 2;
        }
    }

    public void daniarAlguno() {
        if (bota1.estoyRoto) {
            if (bota2.estoyRoto) {
                System.out.println("No se puede daniar lo que no anda.");
            } else {
                bota2.daniarDispositivo();
            }
        } else {
            bota1.daniarDispositivo();
        }
    }
}
