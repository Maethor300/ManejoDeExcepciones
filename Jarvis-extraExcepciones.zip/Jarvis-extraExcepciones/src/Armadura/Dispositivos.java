/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Armadura;

/**
 *
 * @author max72
 */
 public class Dispositivos {

    float consumoBasico;
    float consumoNormal;
    float consumoIntensivo;
    boolean estoyRoto = false;

    public Dispositivos(float consumoBasico, float consumoNormal, float consumoIntensivo) {
        this.consumoBasico = consumoBasico;
        this.consumoNormal = consumoNormal;
        this.consumoIntensivo = consumoIntensivo;
    }

    public float getConsumoBasico() {
        return consumoBasico;
    }

    public void setConsumoBasico(float consumoBasico) {
        this.consumoBasico = consumoBasico;
    }

    public float getConsumoNormal() {
        return consumoNormal;
    }

    public void setConsumoNormal(float consumoNormal) {
        this.consumoNormal = consumoNormal;
    }

    public float getConsumoIntensivo() {
        return consumoIntensivo;
    }

    public void setConsumoIntensivo(float consumoIntensivo) {
        this.consumoIntensivo = consumoIntensivo;
    }

    public Dispositivos() {
    }

    public void daniarDispositivo() {
        estoyRoto = true;
    }

    public void repararDispositivo() {
        estoyRoto = false;
    }

    public boolean verEstadoDispositivo() {
        return estoyRoto;
    }

}
