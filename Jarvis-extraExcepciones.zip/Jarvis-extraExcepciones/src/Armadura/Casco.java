/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Armadura;

/**
 *
 * @author max72
 */
public class Casco extends Dispositivos {

    public Casco() {
        super.consumoBasico = 1;
        super.consumoNormal = 2;
        super.consumoIntensivo = 3;
    }
    /*
        El casco no se dania.
        Porque sino es inusable al 30%
    */

}
