/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Armadura;

/**
 *
 * @author max72
 */
public class Guante {

    Dispositivos guante1;
    Dispositivos guante2;
    float consumoBasico;
    float consumoNormal;
    float consumoIntensivo;

    public Guante() {
        guante1 = new Dispositivos();
        guante2 = new Dispositivos();
        consumoBasico = guante1.consumoBasico;
        consumoNormal = guante1.consumoNormal;
        consumoIntensivo = guante1.consumoIntensivo;
    }

    public int estadoRotil() {
        if (guante1.estoyRoto && guante2.estoyRoto) {
            return 0;
        } else if (guante1.estoyRoto || guante2.estoyRoto) {
            return 1;
        } else {
            return 2;
        }
    }

    public void daniarAlguno() {
        if (guante1.estoyRoto) {
            if (guante2.estoyRoto) {
                System.out.println("No se puede daniar lo que no anda.");
            } else {
                guante2.daniarDispositivo();
            }
        } else {
            guante1.daniarDispositivo();
        }
    }
}
